from flask import Flask, render_template, request, redirect, url_for
from flask_mail import Mail, Message

app = Flask(__name__)
app.config['MAIL_SERVER'] = 'smtp.example.com'  # Update with your SMTP server
app.config['MAIL_PORT'] = 587  # Update with your SMTP port
app.config['MAIL_USERNAME'] = 'Onesmuske'  # Update with your email username
app.config['MAIL_PASSWORD'] = 'Onesmuske123456@'  # Update with your email password
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USE_SSL'] = False
app.config['MAIL_DEFAULT_SENDER'] = 'oneer017@gmail.com'  # Update with your email address

mail = Mail(app)


@app.route('/')
def index():
    return render_portfolio('index.html')


@app.route('/send_email', methods=['POST'])
def send_email():
    name = request.form['name']
    email = request.form['email']
    message = request.form['message']

    msg = Message('Message from Portfolio Website', recipients=['oneer017@gmail.com'])  # Update with your email address
    msg.body = f"Name: {name}\nEmail: {email}\nMessage: {message}"

    mail.send(msg)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
